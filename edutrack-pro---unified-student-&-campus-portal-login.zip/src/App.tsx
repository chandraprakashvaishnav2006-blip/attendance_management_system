import React, { useState } from 'react';
import { UserRole } from './types/auth';
import { UnifiedLoginCard } from './components/UnifiedLoginCard';
import { MobileDeviceMockup } from './components/MobileDeviceMockup';
import { PortalDashboard } from './components/PortalDashboard';
import { SynthesisNotesModal } from './components/SynthesisNotesModal';
import {
  Monitor,
  Smartphone,
  Layers,
  ShieldCheck,
  GraduationCap,
  Sparkles,
  HelpCircle,
  CheckCircle2,
} from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loggedInUser, setLoggedInUser] = useState<{ role: UserRole; identifier: string }>({
    role: 'student',
    identifier: 'alex.walker26',
  });
  const [showSynthesisModal, setShowSynthesisModal] = useState<boolean>(false);

  const handleLoginSuccess = (role: UserRole, userIdentifier: string) => {
    setLoggedInUser({ role, identifier: userIdentifier });
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (isAuthenticated) {
    return (
      <PortalDashboard
        role={loggedInUser.role}
        userIdentifier={loggedInUser.identifier}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f0f4f9] text-slate-800 flex flex-col selection:bg-sky-500 selection:text-white">
      {/* Synthesis Breakdown Modal */}
      <SynthesisNotesModal
        isOpen={showSynthesisModal}
        onClose={() => setShowSynthesisModal(false)}
      />

      {/* Top Application Bar */}
      <header className="w-full bg-white/90 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Brand Wordmark (Single element) */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-black text-base shadow-sm">
              E
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-slate-900 tracking-tight text-base leading-tight">
                EduTrack Pro
              </span>
              <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">
                Unified Authentication System
              </span>
            </div>
          </div>

          {/* Center: Device Viewport Switcher */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200/80">
            <button
              onClick={() => setViewMode('desktop')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'desktop'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Monitor className="w-3.5 h-3.5 text-indigo-600" />
              <span>Desktop Portal</span>
            </button>

            <button
              onClick={() => setViewMode('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'mobile'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-sky-600" />
              <span>Mobile App Frame</span>
            </button>
          </div>

          {/* Right Action: Design Synthesis Info */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSynthesisModal(true)}
              className="flex items-center gap-1.5 py-1.5 px-3 rounded-lg border border-indigo-200 bg-indigo-50/70 text-indigo-700 hover:bg-indigo-100 transition-colors text-xs font-semibold cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Unified 2 UIs Breakdown</span>
              <span className="sm:hidden">Synthesis</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Experience Viewport */}
      <main className="flex-1 flex flex-col justify-center items-center px-4 py-8 sm:py-12 relative overflow-hidden">
        {/* Soft background decorative glow circles */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-sky-200/30 via-indigo-100/40 to-teal-100/30 rounded-full blur-3xl pointer-events-none" />

        {/* View Mode: Desktop Portal Mode */}
        {viewMode === 'desktop' ? (
          <div className="w-full max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            {/* Left Hero & Institutional Trust Info */}
            <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-xs text-xs font-semibold text-slate-700">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Merged Design System · Mobile & Web Synthesis</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
                One unified portal for{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 via-indigo-600 to-teal-600">
                  students, admins & parents
                </span>
                .
              </h1>

              <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl">
                Synthesizing the cheerful student mobile experience with enterprise-grade administration. Choose your role, authenticate with a password or one-time SMS passcode, and manage everything effortlessly.
              </p>

              {/* Feature Points */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/70 border border-slate-200/70 backdrop-blur-xs">
                  <div className="p-1.5 rounded-lg bg-sky-100 text-sky-700 shrink-0">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Student & Guardian Centric</h4>
                    <p className="text-[11px] text-slate-500">Live attendance, schedules & marks</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-white/70 border border-slate-200/70 backdrop-blur-xs">
                  <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-700 shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Enterprise Administration</h4>
                    <p className="text-[11px] text-slate-500">Role-based controls & analytics</p>
                  </div>
                </div>
              </div>

              {/* Bottom Credibility Markers */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-3 text-xs text-slate-500">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Dual Auth (Password & OTP)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>256-Bit SSL Encryption</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Instant Demo Fill</span>
                </div>
              </div>
            </div>

            {/* Right: The Unified Login Card */}
            <div className="lg:col-span-6 flex justify-center">
              <UnifiedLoginCard onLoginSuccess={handleLoginSuccess} />
            </div>
          </div>
        ) : (
          /* View Mode: Mobile Frame Mode (Directly honoring Image 1's smartphone view) */
          <div className="w-full flex flex-col items-center relative z-10">
            <div className="mb-2 text-center">
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-sky-100 text-sky-800 border border-sky-200 inline-flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5" />
                <span>Simulated Mobile View (Matching Image 1 Reference)</span>
              </span>
            </div>
            <MobileDeviceMockup>
              <UnifiedLoginCard
                onLoginSuccess={handleLoginSuccess}
                isMobileDeviceView={true}
              />
            </MobileDeviceMockup>
          </div>
        )}
      </main>

      {/* Clean System Footer */}
      <footer className="w-full bg-white border-t border-slate-200/80 py-4 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">EduTrack Pro</span>
            <span aria-hidden="true">·</span>
            <span>Enterprise Student Management & Analytics System</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <button
              onClick={() => setShowSynthesisModal(true)}
              className="hover:text-indigo-600 transition-colors cursor-pointer"
            >
              Synthesis Documentation
            </button>
            <span aria-hidden="true">·</span>
            <span>Privacy Policy</span>
            <span aria-hidden="true">·</span>
            <span>Support</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
