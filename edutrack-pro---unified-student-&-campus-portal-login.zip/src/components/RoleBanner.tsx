import React from 'react';
import { UserRole, ROLES_CONFIG } from '../types/auth';
import { ShieldCheck, GraduationCap, HeartHandshake } from 'lucide-react';

interface RoleBannerProps {
  role: UserRole;
}

export const RoleBanner: React.FC<RoleBannerProps> = ({ role }) => {
  const config = ROLES_CONFIG[role];

  const getIcon = () => {
    switch (role) {
      case 'admin':
        return <ShieldCheck className="w-5 h-5 text-indigo-600" />;
      case 'student':
        return <GraduationCap className="w-5 h-5 text-sky-600" />;
      case 'parent':
        return <HeartHandshake className="w-5 h-5 text-teal-600" />;
    }
  };

  const getBadgeBg = () => {
    switch (role) {
      case 'admin':
        return 'bg-indigo-100/80 text-indigo-700';
      case 'student':
        return 'bg-sky-100/80 text-sky-700';
      case 'parent':
        return 'bg-teal-100/80 text-teal-700';
    }
  };

  return (
    <div className={`w-full p-3.5 rounded-xl border ${config.themeColor.border} ${config.themeColor.subtle} transition-all duration-300 flex items-start gap-3`}>
      <div className={`p-2 rounded-lg ${getBadgeBg()} shrink-0 mt-0.5`}>
        {getIcon()}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-800 tracking-tight">
            {config.badge}
          </span>
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" title="System Online" />
        </div>
        <p className="text-xs text-slate-600 mt-0.5 leading-relaxed line-clamp-2">
          {config.description}
        </p>
      </div>
    </div>
  );
};
