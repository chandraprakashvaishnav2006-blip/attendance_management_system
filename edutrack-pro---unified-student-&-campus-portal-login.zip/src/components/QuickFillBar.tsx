import React from 'react';
import { UserRole } from '../types/auth';
import { Sparkles, Shield, GraduationCap, Users } from 'lucide-react';

interface QuickFillBarProps {
  onQuickFill: (role: UserRole) => void;
  activeRole: UserRole;
}

export const QuickFillBar: React.FC<QuickFillBarProps> = ({
  onQuickFill,
  activeRole,
}) => {
  return (
    <div className="w-full pt-4 border-t border-slate-100 mt-2">
      <div className="flex items-center justify-center gap-1.5 text-[11px] font-semibold tracking-wider uppercase text-amber-600 mb-2.5">
        <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-spin-slow" />
        <span>QUICK FILL DEMO LOGINS</span>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => onQuickFill('admin')}
          className={`py-1.5 px-2 text-xs font-medium rounded-lg border transition-all flex items-center justify-center gap-1 cursor-pointer ${
            activeRole === 'admin'
              ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-semibold'
              : 'bg-slate-50 border-slate-200/80 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Shield className="w-3 h-3 text-indigo-500" />
          <span>Admin</span>
        </button>

        <button
          type="button"
          onClick={() => onQuickFill('student')}
          className={`py-1.5 px-2 text-xs font-medium rounded-lg border transition-all flex items-center justify-center gap-1 cursor-pointer ${
            activeRole === 'student'
              ? 'bg-sky-50 border-sky-200 text-sky-700 font-semibold'
              : 'bg-slate-50 border-slate-200/80 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <GraduationCap className="w-3 h-3 text-sky-500" />
          <span>Student</span>
        </button>

        <button
          type="button"
          onClick={() => onQuickFill('parent')}
          className={`py-1.5 px-2 text-xs font-medium rounded-lg border transition-all flex items-center justify-center gap-1 cursor-pointer ${
            activeRole === 'parent'
              ? 'bg-teal-50 border-teal-200 text-teal-700 font-semibold'
              : 'bg-slate-50 border-slate-200/80 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Users className="w-3 h-3 text-teal-500" />
          <span>Parent</span>
        </button>
      </div>
    </div>
  );
};
