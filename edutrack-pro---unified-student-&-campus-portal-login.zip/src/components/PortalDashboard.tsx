import React from 'react';
import { UserRole, ROLES_CONFIG } from '../types/auth';
import {
  LogOut,
  Bell,
  Search,
  CheckCircle,
  Calendar,
  Award,
  BookOpen,
  Users,
  Shield,
  Activity,
  CreditCard,
  Clock,
} from 'lucide-react';

interface PortalDashboardProps {
  role: UserRole;
  userIdentifier: string;
  onLogout: () => void;
}

export const PortalDashboard: React.FC<PortalDashboardProps> = ({
  role,
  userIdentifier,
  onLogout,
}) => {
  const config = ROLES_CONFIG[role];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top Navbar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-black text-lg shadow-sm">
              E
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-base">EduTrack Pro</span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${config.themeColor.subtle} ${config.themeColor.text}`}>
                  {config.label}
                </span>
              </div>
              <span className="text-xs text-slate-500 hidden sm:inline">
                Enterprise Student Management & Analytics System
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="w-2 h-2 rounded-full bg-sky-500 absolute top-1.5 right-1.5 ring-2 ring-white"></span>
            </button>

            <div className="h-6 w-px bg-slate-200" />

            <div className="flex items-center gap-2.5 pl-1">
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-xs text-slate-700 uppercase">
                {userIdentifier.slice(0, 2) || 'US'}
              </div>
              <div className="hidden md:block text-left text-xs">
                <p className="font-semibold text-slate-800 truncate max-w-[140px]">{userIdentifier}</p>
                <p className="text-slate-400 capitalize">{role} Account</p>
              </div>
            </div>

            <button
              onClick={onLogout}
              className="ml-2 flex items-center gap-1.5 py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-rose-50 hover:border-rose-200 hover:text-rose-600 transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full flex-1">
        {/* Welcome Greeting Banner */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 mb-1">
              <CheckCircle className="w-4 h-4" />
              <span>Authentication Verified Successfully</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900">
              Welcome back, {role === 'admin' ? 'Administrator' : role === 'student' ? 'Alex Walker' : 'Sarah Walker'}!
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {config.description}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 tabular-nums">
              Session active · 256-bit encrypted
            </span>
          </div>
        </div>

        {/* Dynamic Role Cards */}
        {role === 'admin' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Total Enrolled</span>
                  <Users className="w-5 h-5 text-indigo-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">2,845</div>
                <div className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
                  <span>↑ +4.2%</span> <span className="text-slate-400">vs last semester</span>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Faculty Staff</span>
                  <Shield className="w-5 h-5 text-blue-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">142</div>
                <div className="text-xs text-slate-500 mt-1">98% Active attendance</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Daily Attendance</span>
                  <Activity className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">94.8%</div>
                <div className="text-xs text-emerald-600 mt-1">Campus wide baseline</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Pending Approvals</span>
                  <Clock className="w-5 h-5 text-amber-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">7</div>
                <div className="text-xs text-amber-600 mt-1">Leaves & requisitions</div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h2 className="text-base font-bold text-slate-900 mb-4">Quick Administrative Workflows</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-slate-100 transition-colors">
                  <h3 className="font-semibold text-sm text-slate-800">Student Admissions</h3>
                  <p className="text-xs text-slate-500 mt-1">Review new applications & batch onboarding</p>
                </div>
                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-slate-100 transition-colors">
                  <h3 className="font-semibold text-sm text-slate-800">Class Timetable Scheduler</h3>
                  <p className="text-xs text-slate-500 mt-1">Allocate classrooms and lecturer periods</p>
                </div>
                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-slate-100 transition-colors">
                  <h3 className="font-semibold text-sm text-slate-800">Financial Reports</h3>
                  <p className="text-xs text-slate-500 mt-1">Quarterly tuition audit and fee collection</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {role === 'student' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Cumulative GPA</span>
                  <Award className="w-5 h-5 text-sky-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">3.88 / 4.0</div>
                <div className="text-xs text-sky-600 mt-1">Dean's Honor Roll</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Attendance Rate</span>
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">96.5%</div>
                <div className="text-xs text-emerald-600 mt-1">On track for semester honors</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Active Courses</span>
                  <BookOpen className="w-5 h-5 text-indigo-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">6 Subjects</div>
                <div className="text-xs text-slate-500 mt-1">18 Credits enrolled</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Upcoming Exam</span>
                  <Calendar className="w-5 h-5 text-amber-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900">Physics II</div>
                <div className="text-xs text-amber-600 mt-1">Tomorrow, 10:00 AM</div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h2 className="text-base font-bold text-slate-900 mb-3">Today's Class Schedule</h2>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-semibold bg-sky-100 text-sky-700 px-2 py-1 rounded">09:00 - 10:30 AM</span>
                    <span className="text-sm font-semibold text-slate-800">Advanced Mathematics · Hall 3B</span>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">Prof. Miller</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-semibold bg-indigo-100 text-indigo-700 px-2 py-1 rounded">11:00 - 12:30 PM</span>
                    <span className="text-sm font-semibold text-slate-800">Computer Science Algorithms · Lab 4</span>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">Dr. Henderson</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {role === 'parent' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Student Ward</span>
                  <Users className="w-5 h-5 text-teal-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900">Alex Walker</div>
                <div className="text-xs text-teal-600 mt-1">Grade 10 - Section B</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Attendance (This Month)</span>
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900 tabular-nums">21 / 22 Days</div>
                <div className="text-xs text-emerald-600 mt-1">Present today (08:15 AM)</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Semester Fee Status</span>
                  <CreditCard className="w-5 h-5 text-sky-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900">Paid in Full</div>
                <div className="text-xs text-slate-500 mt-1">Next installment due Nov 15</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-xs font-medium uppercase tracking-wider">Teacher Feedback</span>
                  <Bell className="w-5 h-5 text-indigo-500" />
                </div>
                <div className="text-2xl font-bold text-slate-900">Positive</div>
                <div className="text-xs text-slate-500 mt-1">Parent-teacher meet Oct 12</div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h2 className="text-base font-bold text-slate-900 mb-3">Notice Board & Circulars</h2>
              <div className="space-y-2">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-800">Annual Science Fair 2026 Participation</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Consent forms must be signed before Friday afternoon.</p>
                  </div>
                  <span className="text-xs text-slate-400">Oct 02, 2026</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
