export type UserRole = 'admin' | 'student' | 'parent';

export type AuthMethod = 'password' | 'otp';

export interface RoleConfig {
  id: UserRole;
  label: string;
  badge: string;
  title: string;
  description: string;
  inputLabel: string;
  placeholder: string;
  demoUsername: string;
  demoPassword: string;
  demoPhone: string;
  themeColor: {
    primary: string;
    hover: string;
    gradient: string;
    subtle: string;
    border: string;
    text: string;
    accent: string;
  };
}

export const ROLES_CONFIG: Record<UserRole, RoleConfig> = {
  admin: {
    id: 'admin',
    label: 'Admin',
    badge: 'Admin Portal',
    title: 'System Administrator Access',
    description: 'Full administrative access and institutional system management',
    inputLabel: 'Admin Email / ID',
    placeholder: 'admin@sms.com',
    demoUsername: 'admin@sms.com',
    demoPassword: 'AdminSecurePassword@2026',
    demoPhone: '+1 (555) 942-8821',
    themeColor: {
      primary: 'bg-indigo-600',
      hover: 'hover:bg-indigo-700',
      gradient: 'from-indigo-600 to-blue-600',
      subtle: 'bg-indigo-50/70',
      border: 'border-indigo-100',
      text: 'text-indigo-600',
      accent: '#4f46e5',
    },
  },
  student: {
    id: 'student',
    label: 'Student',
    badge: 'Student Portal',
    title: 'Student Learning Workspace',
    description: 'Access attendance, live courses, assignments & exam grades',
    inputLabel: 'Student ID / Username',
    placeholder: 'STU-2026-8819',
    demoUsername: 'alex.walker26',
    demoPassword: 'StudentPassword@123',
    demoPhone: '+1 (555) 234-5678',
    themeColor: {
      primary: 'bg-sky-500',
      hover: 'hover:bg-sky-600',
      gradient: 'from-sky-500 to-blue-600',
      subtle: 'bg-sky-50/70',
      border: 'border-sky-100',
      text: 'text-sky-600',
      accent: '#0ea5e9',
    },
  },
  parent: {
    id: 'parent',
    label: 'Parent',
    badge: 'Parent Portal',
    title: 'Guardian & Parent Center',
    description: 'Monitor child performance, fee dues, attendance & teacher notices',
    inputLabel: 'Parent Registered Email',
    placeholder: 'parent.sarah@gmail.com',
    demoUsername: 'sarah.walker@family.org',
    demoPassword: 'ParentPassword@456',
    demoPhone: '+1 (555) 876-5432',
    themeColor: {
      primary: 'bg-teal-600',
      hover: 'hover:bg-teal-700',
      gradient: 'from-teal-600 to-sky-600',
      subtle: 'bg-teal-50/70',
      border: 'border-teal-100',
      text: 'text-teal-600',
      accent: '#0d9488',
    },
  },
};
